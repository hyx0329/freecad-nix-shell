The source of the HISA solver. 
See:
https://hisa.gitlab.io
https://gitlab.com/hisa/hisa
